﻿namespace DesignPatterns.InterfaceSegragationPrinciple
{
    public interface IManageable
    {
        void Manage();
    }
}
