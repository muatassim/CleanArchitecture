﻿namespace DesignPatterns.InterfaceSegragationPrinciple
{
    public interface IWorkable
    {
        void Work();
    }
}
