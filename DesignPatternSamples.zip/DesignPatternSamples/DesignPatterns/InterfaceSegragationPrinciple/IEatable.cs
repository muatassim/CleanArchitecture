﻿namespace DesignPatterns.InterfaceSegragationPrinciple
{
    public interface IEatable
    {
        void Eat();
    }
}
