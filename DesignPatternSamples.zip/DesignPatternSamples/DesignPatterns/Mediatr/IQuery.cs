﻿namespace DesignPatterns.Mediatr
{
    public interface IQuery<TResult> { }
}
