﻿namespace DesignPatterns.Mediatr
{
    // Marker interfaces
    public interface ICommand { }
}
