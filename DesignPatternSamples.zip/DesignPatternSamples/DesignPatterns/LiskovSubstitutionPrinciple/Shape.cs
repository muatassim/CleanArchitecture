﻿namespace DesignPatterns.LiskovSubstitutionPrinciple
{
    public abstract class Shape
    {
        public abstract decimal GetArea();
    }
}
