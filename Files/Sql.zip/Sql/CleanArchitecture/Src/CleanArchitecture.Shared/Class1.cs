﻿namespace CleanArchitecture.Shared
{
    public class Class1
    {

    }
}
