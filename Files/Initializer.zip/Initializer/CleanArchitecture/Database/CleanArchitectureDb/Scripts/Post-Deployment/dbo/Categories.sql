﻿PRINT 'Adding Records for dbo.Categories - 0'
BEGIN TRANSACTION

IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Books')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Books', 'Printed and digital reading materials') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Electronics')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Electronics', 'Consumer electronic devices and gadgets') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Clothing')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Clothing', 'Men and women apparel') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Toys')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Toys', 'Toys and games for children') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Groceries')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Groceries', 'Everyday food and household items') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Furniture')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Furniture', 'Home and office furniture') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Sports')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Sports', 'Sports equipment and accessories') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Beauty')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Beauty', 'Cosmetics and personal care') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Garden')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Garden', 'Gardening tools and plants') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Automotive')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Automotive', 'Car parts and accessories') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Music')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Music', 'Musical instruments and media') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Shoes')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Shoes', 'Footwear for all ages') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Jewelry')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Jewelry', 'Rings, necklaces, and accessories') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Office Supplies')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Office Supplies', 'Stationery and office essentials') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Health')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Health', 'Healthcare and wellness products') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Pets')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Pets', 'Pet food and accessories') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Travel')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Travel', 'Luggage and travel accessories') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Games')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Games', 'Board games and video games') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Baby')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Baby', 'Baby care and products') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Art')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Art', 'Art supplies and materials') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Watches')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Watches', 'Wristwatches and timepieces') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Bags')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Bags', 'Handbags, backpacks, and luggage') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Kitchen')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Kitchen', 'Kitchenware and appliances') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Cleaning')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Cleaning', 'Cleaning supplies and tools') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Lighting')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Lighting', 'Lamps and lighting fixtures') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Outdoors')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Outdoors', 'Outdoor gear and equipment') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Stationery')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Stationery', 'Writing and office materials') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Crafts')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Crafts', 'Crafting supplies and kits') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Beverages')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Beverages', 'Drinks and refreshments') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Snacks')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Snacks', 'Snack foods and treats') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Dairy')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Dairy', 'Milk, cheese, and dairy products') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Bakery')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Bakery', 'Bread, cakes, and pastries') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Seafood')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Seafood', 'Fish and seafood products') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Meat')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Meat', 'Fresh and processed meats') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Poultry')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Poultry', 'Chicken, turkey, and other poultry') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Frozen Foods')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Frozen Foods', 'Frozen meals and desserts') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Canned Goods')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Canned Goods', 'Canned foods and preserves') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Condiments')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Condiments', 'Sauces, spices, and seasonings') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Pasta')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Pasta', 'Pasta and noodles') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Rice')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Rice', 'Rice and grains') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Cereals')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Cereals', 'Breakfast cereals and granola') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Sauces')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Sauces', 'Cooking sauces and dressings') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Spices')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Spices', 'Herbs and spices') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Vegan')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Vegan', 'Plant-based foods') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Gluten-Free')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Gluten-Free', 'Gluten-free products') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Organic')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Organic', 'Organic certified foods') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Supplements')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Supplements', 'Vitamins and dietary supplements') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Energy Drinks')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Energy Drinks', 'Energy and sports drinks') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Tea')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Tea', 'Tea and herbal infusions') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Coffee')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Coffee', 'Coffee beans and blends') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Wine')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Wine', 'Red, white, and sparkling wines') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Beer')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Beer', 'Craft and commercial beers') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Spirits')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Spirits', 'Whiskey, vodka, and liquors') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Soda')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Soda', 'Soft drinks and sodas') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Water')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Water', 'Bottled and mineral water') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Juice')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Juice', 'Fruit and vegetable juices') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Ice Cream')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Ice Cream', 'Ice cream and frozen desserts') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Chocolates')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Chocolates', 'Chocolate bars and candies') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Candy')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Candy', 'Sweets and confectionery') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Nuts')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Nuts', 'Nuts and dried fruits') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Deli')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Deli', 'Deli meats and cheeses') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Prepared Foods')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Prepared Foods', 'Ready-to-eat meals') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Salads')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Salads', 'Fresh salads and greens') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Soups')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Soups', 'Canned and fresh soups') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Sauerkraut')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Sauerkraut', 'Fermented cabbage products') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Pickles')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Pickles', 'Pickled vegetables') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Honey')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Honey', 'Honey and bee products') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Jams')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Jams', 'Jams and fruit spreads') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Syrups')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Syrups', 'Maple and flavored syrups') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Vinegar')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Vinegar', 'Vinegar and dressings') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Oils')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Oils', 'Cooking oils and sprays') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Baking')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Baking', 'Baking ingredients and mixes') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Flour')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Flour', 'Flour and baking essentials') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Sugar')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Sugar', 'Sugar and sweeteners') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Eggs')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Eggs', 'Fresh eggs and substitutes') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Herbs')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Herbs', 'Fresh and dried herbs') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Mushrooms')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Mushrooms', 'Fresh and dried mushrooms') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Tofu')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Tofu', 'Tofu and soy products') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Seaweed')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Seaweed', 'Edible seaweed products') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Yogurt')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Yogurt', 'Yogurt and cultured dairy') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Cheese')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Cheese', 'Cheese and cheese products') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Butter')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Butter', 'Butter and margarine') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Milk')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Milk', 'Milk and milk alternatives') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Cream')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Cream', 'Cream and creamers') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Sausages')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Sausages', 'Sausages and cured meats') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Ham')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Ham', 'Ham and pork products') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Bacon')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Bacon', 'Bacon and breakfast meats') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Lamb')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Lamb', 'Lamb and mutton products') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Beef')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Beef', 'Beef and veal products') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Pork')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Pork', 'Pork and pork products') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Turkey')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Turkey', 'Turkey and turkey products') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Duck')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Duck', 'Duck and specialty poultry') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Shellfish')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Shellfish', 'Shrimp, crab, and shellfish') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Crab')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Crab', 'Crab and crab products') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Lobster')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Lobster', 'Lobster and shellfish') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Salmon')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Salmon', 'Salmon and fish products') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Tuna')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Tuna', 'Tuna and canned fish') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Trout')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Trout', 'Trout and freshwater fish') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Cod')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Cod', 'Cod and white fish') END
IF NOT EXISTS (SELECT 1 FROM [dbo].[Categories] WHERE [CategoryName] = 'Mackerel')
BEGIN INSERT INTO [dbo].[Categories] ([CategoryName], [Description]) VALUES ('Mackerel', 'Mackerel and oily fish') END

COMMIT TRANSACTION
GO

PRINT 'End Adding Records for dbo.Categories >> 100'