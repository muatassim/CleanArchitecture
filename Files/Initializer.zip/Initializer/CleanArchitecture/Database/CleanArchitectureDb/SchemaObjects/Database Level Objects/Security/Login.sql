﻿CREATE LOGIN [DataTransferUser] WITH PASSWORD = 'CHNWdJskkS@@1q$DZfla'
