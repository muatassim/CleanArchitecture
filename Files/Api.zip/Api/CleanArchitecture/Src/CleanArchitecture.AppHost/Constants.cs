namespace CleanArchitecture.AppHost
{
    /// <summary>
    /// T
    /// </summary>
    public class Constants
    {
        public const string ApiProjectName = "Api";
    }
}
