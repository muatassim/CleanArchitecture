using CleanArchitecture.ApiShared.Models;
namespace CleanArchitecture.ApiShared.Interfaces.Api
{
    public interface ICategoriesModelApi : IApi<CategoriesModel, int>
    {
    }
}
