namespace CleanArchitecture.Api.Helpers
{
    public static class Constants
    {
        public const string MyAllowSpecificOrigins = "MyAllowSpecificOrigins";
    }
}
