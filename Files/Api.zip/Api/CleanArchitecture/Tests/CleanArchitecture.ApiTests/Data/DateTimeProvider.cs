namespace CleanArchitecture.ApiTests.Data
{
    sealed class DateTimeProvider
    {
        public static DateTime UtcNow => DateTime.UtcNow;
    }
}
